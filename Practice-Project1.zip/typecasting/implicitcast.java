package typecasting;

public class implicitcast {

	public static void main(String[] args) {
	 byte p = 10;
	 System.out.println("the value of p:" +p);
	 int q = p;
	 System.out.println("the value of q:"+q);
	}

}
