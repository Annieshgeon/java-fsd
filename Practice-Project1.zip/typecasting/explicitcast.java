package typecasting;

public class explicitcast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double d = 13.09;
long l  = (long)d;
System.out.println("the value of l: "+l);
	}

}
