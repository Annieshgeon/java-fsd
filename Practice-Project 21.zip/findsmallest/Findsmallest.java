package findsmallest;

public class Findsmallest {

}
