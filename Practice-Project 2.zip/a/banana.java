package a;

public class banana {

	public static void main(String[] args) {
Apple a = new Apple();
System.out.println(a.apples);

	}

}
