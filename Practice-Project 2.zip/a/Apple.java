package a;

public class Apple {
protected int apples=2;
}
