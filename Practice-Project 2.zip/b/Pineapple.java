package b;

import a.Apple;

public class Pineapple {

	public static void main(String[] args) {
		Apple a = new Apple();
		System.out.println(a.apples);

	}

}
