package empinfo;

public class Constructordemo {

	public static void main(String[] args) {

		Empinfo emp1=new Empinfo();
		Empinfo emp2=new Empinfo();

		emp1.display();
		emp2.display();
		}
	}
