package empinfo;

public class Empinfo {
	int id;
	String name;

void display() {
	System.out.println(id+" "+name);
	}
}

